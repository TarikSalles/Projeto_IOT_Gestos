# projeto libras > 2024-10-20 7:43pm
https://universe.roboflow.com/gomes-project/projeto-libras

Provided by a Roboflow user
License: CC BY 4.0

